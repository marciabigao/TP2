#include "../include/Nos.hpp"

NoFila::NoFila() {
    id = -1;
    proximo = nullptr;
}

NoLista::NoLista() {
    id = -1;
    proximo = nullptr;
}

NoPilha::NoPilha() {
    proximo = nullptr;
    pacote = nullptr;
}