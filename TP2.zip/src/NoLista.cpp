#include "../include/NoLista.hpp"

NoLista::NoLista() {
    id = -1;
    proximo = nullptr;
}
