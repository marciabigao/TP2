#include "../include/NoFila.hpp"

NoFila::NoFila() {
    id = -1;
    proximo = nullptr;
}