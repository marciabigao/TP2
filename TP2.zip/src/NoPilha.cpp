#include "../include/NoPilha.hpp"

NoPilha::NoPilha() {
    proximo = nullptr;
    pacote = nullptr;
}